from flask import Flask, render_template, request, jsonify, url_for

app = Flask(__name__)

BOOKS = [
    {
        "id": 1,
        "title": "Lập trình Python",
        "author": "Nguyễn Văn A",
        "year": 2024,
        "category": "Lập trình",
        "available": True
    },
    {
        "id": 2,
        "title": "Lập trình Java",
        "author": "Nguyễn Văn B",
        "year": 2023,
        "category": "Lập trình",
        "available": True
    },
    {
        "id": 3,
        "title": "Cơ sở dữ liệu",
        "author": "Nguyễn Văn C",
        "year": 2022,
        "category": "Cơ sở dữ liệu",
        "available": False
    },
    {
        "id": 4,
        "title": "HTML CSS",
        "author": "Nguyễn Văn D",
        "year": 2024,
        "category": "Web",
        "available": True
    }
]


@app.route("/")
def index():
    total = len(BOOKS)
    available = sum(book["available"] for book in BOOKS)

    return render_template(
        "index.html",
        total=total,
        available=available
    )


@app.route("/books")
def books():
    category = request.args.get("category")

    if category:
        result = [
            book for book in BOOKS
            if book["category"] == category
        ]
    else:
        result = BOOKS

    return render_template(
        "books.html",
        books=result
    )


@app.route("/books/<int:book_id>")
def book_detail(book_id):
    book = next(
        (book for book in BOOKS if book["id"] == book_id),
        None
    )

    if book is None:
        return "Không có sách với ID = " + str(book_id), 404

    return render_template("detail.html", book=book)


@app.route("/api/books")
def api_books():
    return jsonify(BOOKS)


@app.route("/api/books/<int:book_id>")
def api_book(book_id):
    book = next(
        (book for book in BOOKS if book["id"] == book_id),
        None
    )

    if book is None:
        return jsonify({"error": "Không có sách"}), 404

    return jsonify(book)


if __name__ == "__main__":
    app.run(debug=True)